<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$test_ami = 0;
$test_any = 0;
global $amp_conf;

$driver = $this->FreePBX->Core->getAllDriversInfo();
$core = $this->aminterface->getSCCPVersion();
$ast_realtime = $this->aminterface->getRealTimeStatus();

//$ast_realm = (empty($ast_realtime['sccp']) ? '' : 'sccp');

// if there are multiple connections, this will only return the first.
$ast_realm = '';
if (is_array($ast_realtime)) {
    foreach ($ast_realtime as $key => $value) {
        if ($ast_realm === '' && isset($value['status']) && $value['status'] === 'OK') {
            $ast_realm = $key;
            break;
        }
    }
}

$conf_realtime = $this->extconfigs->validate_RealTime($ast_realm);
$db_Schema = $this->dbinterface->validate();
$mysql_info = $this->dbinterface->get_db_sysvalues();
$compatible = $this->aminterface->get_compatible_sccp();
$info = array();

//$info['srvinterface'] = $this->srvinterface->info();
$moduleXml = simplexml_load_file("{$amp_conf['AMPWEBROOT']}/admin/modules/sccp_manager/module.xml");
$info['extconfigs'] = $this->extconfigs->info();
$info['dbinterface'] = $this->dbinterface->info();
$info['aminterface'] = $this->aminterface->info();
$info['XML'] = $this->xmlinterface->info();
$info['sccp_class'] = $driver['sccp'] ?? '';
$coreVersion = $core['Version'] ?? '';
$coreVCode = $core['vCode'] ?? '';
$coreRev = $core['RevisionNum'] ?? '';
$coreHash = $core['RevisionHash'] ?? '';
$coreBuildInfo = $core['buildInfo'] ?? array();
$info['Core_sccp'] = array('Version' => $coreVersion,
                            'about' => "Sccp ver: {$coreVersion}   r{$coreVCode}   Revision: {$coreRev}   Hash: {$coreHash}");
$capabilityArray = array( "park", "pickup", "realtime", "video", "conference", "dirtrfr", "feature_monitor", "functions", "manager_events",
                          "devicestate", "devstate_feature", "dynamic_speeddial", "dynamic_speeddial_cid", "experimental", "debug");

$info['chan-sccp build info'] = array('Version' => $coreVersion, 'about' => 'Following options NOT built:  ' . implode('; ', array_diff($capabilityArray, $coreBuildInfo)));
$info['Asterisk'] = array('Version' => FreePBX::Config()->get('ASTVERSION'), 'about' => 'Asterisk.');

if (!empty($this->sccpvalues['SccpDBmodel'])) {
    $info['DB Model'] = array('Version' => $this->sccpvalues['SccpDBmodel']['data'], 'about' => 'SCCP DB Configure');
}

exec('in.tftpd -V', $tftpInfo);
$tftpParts = array();
$info['TFTP Server'] = array('Version' => 'Not Found', 'about' => 'Mapping not available');

if (isset($tftpInfo[0])) {
    $tftpParts = explode(',', $tftpInfo[0]);
    $info['TFTP Server'] = array('Version' => $tftpParts[0] ?? '', 'about' => 'Mapping not available');
    if (isset($tftpParts[1])) {
        $tftpParts[1] = trim($tftpParts[1]);
        if ($tftpParts[1] === 'with remap') {
            $info['TFTP Server'] = array('Version' => $tftpParts[0] ?? '', 'about' => $tftpParts[1]);
        }
    }
}

if (!empty($this->sccpvalues['tftp_rewrite']['data'])) {
    switch ($this->sccpvalues['tftp_rewrite']['data']) {
      case 'custom':
      case 'pro':
          $info['Provision_SCCP'] = array('Version' => 'base', 'about' => 'Provision Sccp enabled');
          break;
      default:
          if (isset($tftpParts[1]) && $tftpParts[1] === 'with remap') {
              $info['TFTP_Mapping'] = array('Version' => 'off', 'about' => "TFTP mapping is available but the mapping file is not included in tftpd-hpa default settings.<br>
                                            To enable Provision mode, add option <br>
                                            -m /etc/asterisk/sccpManagerRewrite.rules <br>
                                            to the tftpd defaults, (location dependant on the system), and restart the tftpd server");

          } else {
              $info['TFTP_Mapping'] = array('Version' => 'off', 'about' => "Mapping capability is not built into the TFTP server. To enable Provision, upgrade the TFTP server.");
          }
          break;
    }
}

// Finished testing tftp server options
$info['Сompatible'] = array('Version' => $compatible, 'about' => 'Ok');
if (!empty($this->sccpvalues['SccpDBmodel'])) {
    if ($compatible > $this->sccpvalues['SccpDBmodel']['data']) {
        $info['Сompatible']['about'] = 'Reinstall SCCP manager required';
    }
}
if ($db_Schema == 0) {
    $info['DB_Schema'] = array('Version' => 'Error', 'about' => 'ERROR DB Version');
} else {
    $info['DB_Schema'] = array('Version' => $db_Schema, 'about' => (($compatible == $db_Schema ) ? 'Ok' : 'Incompatible Version'));
}

if (empty($ast_realtime)) {
    $info['RealTime'] = array('Version' => 'Error', 'about' => 'No RealTime connections found');
} else {
    $rt_info = '';
    $rt_sccp = 'Failed';
    foreach ($ast_realtime as $key => $value) {
        $vStatus = $value['status'] ?? '';
        $vRealm = $value['realm'] ?? '';
        $vMessage = $value['message'] ?? '';
        if ($key == $ast_realm) {
            if ($vStatus == 'OK') {
                $rt_sccp = 'TEST OK';
                $rt_info .= ($rt_info !== '' ? "\n" : '') . 'Using SCCP connection found to database: ' . htmlspecialchars($vRealm) . ' with connector: [' . htmlspecialchars($key) . ']';
            } else {
                $rt_sccp = 'SCCP ERROR';
                $rt_info .= ($rt_info !== '' ? "\n" : '') . 'Error: ' . htmlspecialchars($vMessage);
            }
        } elseif ($vStatus == 'ERROR') {
            $rt_info .= ($rt_info !== '' ? "\n" : '') . 'No connector found for [' . htmlspecialchars($key) . ']: ' . htmlspecialchars($vMessage);
        } elseif ($vStatus == 'OK') {
            $rt_info .= ($rt_info !== '' ? "\n" : '') . 'Alternative connector found to database ' . htmlspecialchars($vRealm) . ' with connector: [' . htmlspecialchars($key) . ']';
        }
    }
    $info['RealTime'] = array('Version' => $rt_sccp, 'about' => $rt_info);
}
$phpVer = phpversion();
$info['PHP'] = array('Version' => $phpVer, 'about' => version_compare($phpVer, '8.2.0', '>=') ? 'OK' : 'PHP 8.2+ required for FreePBX 16/17');
$mariaDbInfo = exec('mysql -V');
$mariaParts = $mariaDbInfo ? explode(' ', $mariaDbInfo) : array();
$info['MariaDb'] = array('Version' => isset($mariaParts[3]) ? $mariaParts[3] : 'n/a', 'about' => $mariaDbInfo ?: 'mysql not in PATH');

if (empty($conf_realtime)) {
    $info['ConfigsRealTime'] = array('Version' => 'Error', 'about' => 'Realtime configuration was not found');
} else {
    $rt_info = '';
    foreach ($conf_realtime as $key => $value) {
        if (($value != 'OK') && ($key != 'extconfigfile')) {
            $rt_info .= ($rt_info !== '' ? "\n" : '') . 'Found error in section ' . $this->escapeHtml($key) . ': ' . $this->escapeHtml($value);
        }
    }
    if (!empty($rt_info)) {
        $info['ConfigsRealTime'] = array('Version' => 'Error', 'about' => $rt_info);
    }
}
// $mysql_info - SHOW VARIABLES returns Variable_name, Value (or similar)
if (!empty($mysql_info) && isset($mysql_info['Value']) && $mysql_info['Value'] <= '2000') {
    $this->info_warning['MySql'] = array('Increase Mysql Group Concat Max. Length', 'Step 1: Go to mysql path <br> nano /etc/my.cnf',
        'Step 2: And add the following line below [mysqld] as shown below <br> [mysqld] <br>group_concat_max_len = 4096 or more',
        'Step 3: Save and restart <br> systemctl restart mariadb.service<br> Or <br> service mysqld restart');
}


// Check Time Zone compatibility
$conf_tz = $this->sccpvalues['ntp_timezone']['data'] ?? '';
$cisco_tz = $this->extconfigs->getExtConfig('sccp_timezone', $conf_tz);
if (isset($cisco_tz['offset']) && $cisco_tz['offset'] == 0) {
    if (!empty($conf_tz)) {
        $tmp_dt = new DateTime('now', new DateTimeZone($conf_tz));
        $tmp_ofset = $tmp_dt->getOffset();
        if (isset($cisco_tz['offset']) && ($cisco_tz['offset'] != ($tmp_ofset / 60) )) {
            $this->info_warning['NTP'] = array('The selected NTP time zone is not supported by cisco devices.', 'We will use the Greenwich Time zone');
        }
    }
}

if (!empty($this->info_warning)) {
    ?>
    <div class="fpbx-container container-fluid">
        <div class="row">
            <div class="container">
                <h2 style="border:2px solid Tomato;color:Tomato;" ><?php echo _("Sccp Manager Warning"); ?></h2>
                <div class="table-responsive">
                    <br> <?php echo _("There are Warning in the SCCP Module:"); ?><br><pre>
                        <?php
                        foreach ($this->info_warning as $key => $value) {
                            echo '<h3>' . $this->escapeHtml($key) . '</h3>';
                            if (is_array($value)) {
                                echo '<li>' . $this->escapeHtml(_(implode('</li><li>', $value))) . '</li>';
                            } else {
                                echo '<li>' . $this->escapeHtml(_($value)) . '</li>';
                            }
                            echo '<br>';
                        }
                        ?>
                    </pre>
                    <br><h4 style="border:2px solid Tomato;color:Green;" > <?php echo _("Check these problems before continuing to work."); ?></h4> <br>
                </div>
            </div>
        </div>
    </div>
    <br>
    <?php
}

if (!empty($this->class_error)) {
    ?>
    <div class="fpbx-container container-fluid">
        <div class="row">
            <div class="container">
                <h2 style="border:2px solid Tomato;color:Tomato;" ><?php echo _("Diagnostic information about SCCP Manager errors"); ?></h2>
                <div class="table-responsive">
                    <br> <?php echo _("There is an error in the module:"); ?><br><pre>
    <?php echo $this->escapeHtml(print_r($this->class_error, true)); ?>
                    </pre>
                    <br> <?php echo _("Correct these problems before continuing to work."); ?> <br>
                    <br><h3 style="border:2px solid Tomato;color:Green;" > <?php echo _("Open 'SCCP Connectivity' -> Server Config' to change global settings"); ?></h3> <br>
                </div>
            </div>
        </div>
    </div>
    <br>
<?php } ?>
<div class="fpbx-container container-fluid">
    <div class="row">
        <div class="container">
            <h2><?php echo _("Sccp Manager"); ?> v<?php echo $this->escapeHtml((string) $moduleXml->version); ?> <?php echo _("Info"); ?> </h2>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php echo _("Module"); ?></th>
                            <th><?php echo _("Version"); ?></th>
                            <th><?php echo _("Info"); ?></th>
                        </tr>
                    </thead>
                    <tbody>
<?php
foreach ($info as $key => $value) {
    echo '<tr><td>' . $this->escapeHtml($key) . '</td><td>' . $this->escapeHtml($value['Version'] ?? '') . '</td><td>' . $this->escapeHtml($value['about'] ?? '') . '</td></tr>';
}
?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-default" href="ajax.php?module=sccp_manager&command=backupsettings"><i class="fa fa-plane">&nbsp;</i><?php echo _("BackUp Config") ?></a>
        </div>

    </div>
</div>
<?php echo $this->showGroup('sccp_info', 0); ?>
